# Discounting & brand-health tracker — 2026-06-29

_Thesis check: falling % on sale + shallower depth + faster sell-outs + more full-price newness + lower outlet reliance = brand healing / less promotional._

## Kate Spade
- % of SKUs on sale: **40.0%** (+15.0 pts WoW)
- Avg discount depth (on-sale): **35.0%**
- New arrivals at full price: **0.0%** (1 new styles)
- Sell-out rate WoW: **25.0%** (1 styles)
- Median time-to-markdown: **7.0 days**
- Outlet share of assortment: **44.4%**
